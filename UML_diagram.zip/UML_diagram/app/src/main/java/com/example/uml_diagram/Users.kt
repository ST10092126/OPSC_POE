package com.example.uml_diagram

import java.time.LocalDate

class Users {companion object {
    public var user: Users? = null // static user object
}

    private var username: String = ""
    private var password: String = ""
    private var name: String = ""
    private lateinit var categories: MutableList<Category>
    private var goals: Goals = Goals()

    fun getGoal(): Goals {
        return goals
    }

    fun setGoal(goal: Goals) {
        this.goals = goal
    }

    fun getUsername(): String {
        return username
    }


    fun setUsername(username: String) {
        this.username = username
    }

    fun getPassword(): String {
        return password
    }


    fun setPassword(password: String) {
        this.password = password
    }

    fun getName(): String {
        return name
    }

    fun setName(name: String) {
        this.name = name
    }


    fun addCategories(obj: Category) {
        categories.add(obj)
    }


    fun getCategories(): List<Category> {
        return categories.toList()
    }

    fun createUser(name: String, username: String, password: String) {
        val newUser = Users()
        newUser.setName(name)
        newUser.setUsername(username)
        newUser.setPassword(password)
        user =(newUser)
    }



}