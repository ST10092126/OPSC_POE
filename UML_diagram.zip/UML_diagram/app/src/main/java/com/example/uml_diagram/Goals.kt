package com.example.uml_diagram

class Goals {

    private var minimumGoal: Int = 0
    private var maximumGoal: Int = 0

    fun getminimum(): Int {
        return minimumGoal
    }

    fun setminimum(Minimum: Int) {
        this.minimumGoal = Minimum
    }

    fun getmaximum(): Int {
        return maximumGoal
    }

    fun setmaximum(Maximum: Int) {
        this.maximumGoal = Maximum
    }

    fun createGoals(minimumGoal:Int, maximumGoal:Int ){
        this.maximumGoal=maximumGoal
        this.minimumGoal=minimumGoal
    }
}