package com.example.uml_diagram

import java.text.DateFormat

class Timesheets  {

    private var categoryName: String = ""
    private var dateCreated: String =""
    private var startDate: String = ""
    private var endDate: String = ""
    private var description: String = ""

    fun getCategoryName(): String {
        return categoryName
    }

    fun setCategoryName(categoryName: String) {
        this.categoryName = categoryName
    }


    fun getDateCreated(): String {
        return dateCreated
    }

    fun setDateCreated(datecreated: String) {
        this.dateCreated = datecreated
    }

    fun getStartDate(): String {
        return startDate
    }

    fun setStartDate(startDate: String) {
        this.startDate = startDate
    }

    fun getEndDate(): String {
        return endDate
    }
    fun setEndDate(endDate: String) {
        this.endDate = endDate
    }

    fun setDescription(Description: String) {
        this.description = Description
    }

    fun getDescription(): String {
        return description
    }



    fun createTimeSheet(categoryName: String,description: String,dateCreated: String, startDate: String, endDate: String) :Timesheets{
        val timesheet = Timesheets()
        timesheet.setCategoryName(categoryName)
        timesheet.setDateCreated(dateCreated)
        timesheet.setDescription(description)
        timesheet.setStartDate(startDate)
        timesheet.setEndDate(endDate)

        return timesheet
    }
}