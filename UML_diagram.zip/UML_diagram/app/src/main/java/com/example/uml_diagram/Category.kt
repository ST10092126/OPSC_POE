package com.example.uml_diagram

class Category {


    private var categoryName: String = ""
    private var totalNumberOfHours: Double = 0.0
    private var categoryType: String = ""
    private lateinit var TimeSheets: MutableList<Timesheets>


    fun getCategoryName(): String {
        return categoryName
    }


    fun setCategoryName(categoryName: String) { this.categoryName = categoryName
    }

    fun getTotalNumberOfHours(): Double {
        return totalNumberOfHours
    }


    fun setTotalNumberOfHours(totalNumberOfHours: Double) {
        this.totalNumberOfHours = totalNumberOfHours
    }


    fun getCategoryType(): String {
        return categoryType
    }

    fun setCategoryType(CategoryType: String) {
        this.categoryType = CategoryType
    }


    fun getTimeSheets(): List<Timesheets> {
        return TimeSheets
    }


    fun addTimeSheets(timeSheet: Timesheets) {
        this.TimeSheets.add(timeSheet)
    }

    fun createCategory(categoryName: String, categoryType: String) {
        val category = Category()
        category.setCategoryName(categoryName)
        category.setCategoryType(categoryType)
        Users.user?.addCategories(category)
    }
}